# Change Log

All notable changes to the "vscode-backup" extension will be documented in this file.

## Release Notes

### 0.0.5

Linux Support Added  
Some House Cleaning  
*Check [Known Issues](https://github.com/DK013/vscdoe-backup/blob/master/README.md##known-issues) for possible problems in different environment

### 0.0.4

macOS support added

### 0.0.3

New Zip Library for macOS Support  
macOS tests started

### 0.0.2

Added Icons and Manifest for Marketplace

### 0.0.1

Initial release of vscode backup for Windows

**Enjoy!**